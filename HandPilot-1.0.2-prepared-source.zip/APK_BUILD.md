# HandPilot — Android build handoff

## Build an installable APK

HandPilot includes an Android-only Expo native module; Expo Go cannot provide its CameraX, MediaPipe, foreground-service, or AccessibilityService code. The Sandbox has no Android SDK, so native release builds must be made through the managed Dashboard from an accepted source checkpoint. Open the HandPilot project, choose an Android **APK** build, and select the `apk` profile if prompted. Download the artifact returned by the build; the source ZIP does not contain an installable APK.

The Android package identifier is `space.manus.handpilot.t205460580683166`. The APK targets Android API 24+ and includes the bundled hand-landmarker model in `modules/handpilot/android/src/main/assets/hand_landmarker.task`.

## Build for Google Play

The `production` EAS profile is configured to create an Android App Bundle (`.aab`) for store distribution. In the Dashboard choose **Build for publish**. If the Dashboard asks for Expo account authorization or app-signing credentials, enter them only in its secure form—never in chat or project source.

Building an AAB does not publish the app. Google Play submission requires a Play Console listing and review, accurate privacy/Data safety information, and a Play AccessibilityService declaration. The Accessibility permission needs a clear in-app explanation and consent when applicable. Test the finished app on real Android phones before asking the public to install it. Only describe the Play build as ready when the Dashboard returns the actual AAB.

## First launch

1. Install and open the APK. Tap **Start hand control** and grant camera access. On Android 13+, also allow notifications so the foreground camera-tracking notification remains visible.
2. Tap **Open Accessibility Settings**, find **HandPilot hand controls** in Android's Accessibility list, and explicitly turn it on. Android's wording and menu location vary by manufacturer. Return to HandPilot.
3. Hold an open palm still to show the pointer. Set sensitivity and smoothing, then calibrate with your hand in the camera frame. Keep the phone awake, unlocked, and the front camera well lit.
4. Use a fist to pause; hold an open palm to resume. Tap **Stop camera tracking** or the notification's Stop action to stop the camera service.

## Gestures and system actions

| Input | HandPilot action |
| --- | --- |
| Hold an open palm still | Show/hide the pointer; when paused, hold to resume. |
| Brief thumb–index pinch and release | Tap at the pointer. |
| Hold a still pinch | Long-press. |
| Pinch, move, and release | Drag along the tracked path. |
| Fast sweep left | Android Back. |
| Fast sweep right | Send a right swipe. |
| Fast sweep up/down | Send a corresponding scroll swipe. |
| Move two hands closer/farther | Request a two-finger zoom gesture in the current app. |
| Closed fist | Pause new gesture commands; an open palm held steady resumes. |

The controller dashboard also exposes Back, Home, Recents, notifications, Quick Settings, screenshot, lock screen, and power menu controls where Android supports them, and allows launchable apps to be opened or starred as shortcuts.

## Privacy and limitations

Camera frames and hand landmarks are processed on-device by MediaPipe and CameraX; the controller does not upload or record them. The AccessibilityService is configured not to retrieve window content, but Android still asks the user to explicitly grant the service. Android versions, device camera orientation/frame rate, lighting, hand occlusion, target-app behavior, navigation mode, and system policies can change whether a global action or injected gesture succeeds. Secure, permission, payment, or other protected screens may reject gestures; HandPilot does not and cannot bypass the phone's PIN, biometric, or other security checks. The camera notification is visible while tracking continues outside the app.

The Web Preview is only a layout preview: it deliberately does not open the browser camera or simulate detection. The Android native code has passed Expo prebuild and TypeScript/config checks, but must still be compiled by the Dashboard and exercised on a real Android device before native tracking accuracy can be confirmed.

## Platform references

- [Expo local native modules](https://docs.expo.dev/modules/get-started/)
- [Expo EAS build profile configuration](https://docs.expo.dev/build/eas-json/)
- [Android Accessibility services](https://developer.android.com/guide/topics/ui/accessibility/service)
- [Android AccessibilityService reference](https://developer.android.com/reference/android/accessibilityservice/AccessibilityService)
- [MediaPipe Hand Landmarker for Android](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/android)
- [Expo Android APK builds](https://docs.expo.dev/build-reference/apk/)
