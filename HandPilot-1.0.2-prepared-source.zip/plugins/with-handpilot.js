const fs = require('node:fs/promises');
const path = require('node:path');
const { withAndroidManifest, withDangerousMod, withStringsXml } = require('expo/config-plugins');

const A11Y_SERVICE = 'expo.modules.handpilot.HandPilotAccessibilityService';
const TRACKING_SERVICE = 'expo.modules.handpilot.HandPilotTrackingService';

function withHandPilot(config) {
  config = withAndroidManifest(config, (mod) => {
    const manifest = mod.modResults.manifest;
    manifest['uses-permission'] ??= [];
    const permissions = [
      'android.permission.CAMERA',
      'android.permission.FOREGROUND_SERVICE',
      'android.permission.FOREGROUND_SERVICE_CAMERA',
      'android.permission.POST_NOTIFICATIONS',
    ];
    for (const permission of permissions) {
      if (!manifest['uses-permission'].some((item) => item.$?.['android:name'] === permission)) {
        manifest['uses-permission'].push({ $: { 'android:name': permission } });
      }
    }

    manifest['uses-feature'] ??= [];
    if (!manifest['uses-feature'].some((item) => item.$?.['android:name'] === 'android.hardware.camera.front')) {
      manifest['uses-feature'].push({
        $: { 'android:name': 'android.hardware.camera.front', 'android:required': 'true' },
      });
    }

    manifest.queries ??= [{}];
    const query = manifest.queries[0];
    query.intent ??= [];
    const hasLauncherQuery = query.intent.some((item) =>
      (item.action ?? []).some((action) => action.$?.['android:name'] === 'android.intent.action.MAIN') &&
      (item.category ?? []).some((category) => category.$?.['android:name'] === 'android.intent.category.LAUNCHER'),
    );
    if (!hasLauncherQuery) {
      query.intent.push({
        action: [{ $: { 'android:name': 'android.intent.action.MAIN' } }],
        category: [{ $: { 'android:name': 'android.intent.category.LAUNCHER' } }],
      });
    }

    const application = manifest.application?.[0];
    if (!application) throw new Error('HandPilot could not find the Android application manifest entry.');
    application.service ??= [];
    const ensureService = (name, service) => {
      const index = application.service.findIndex((item) => item.$?.['android:name'] === name);
      if (index >= 0) application.service[index] = service;
      else application.service.push(service);
    };

    ensureService(A11Y_SERVICE, {
      $: {
        'android:name': A11Y_SERVICE,
        'android:permission': 'android.permission.BIND_ACCESSIBILITY_SERVICE',
        'android:exported': 'true',
        'android:label': '@string/handpilot_accessibility_label',
        'android:description': '@string/handpilot_accessibility_description',
      },
      'intent-filter': [{ action: [{ $: { 'android:name': 'android.accessibilityservice.AccessibilityService' } }] }],
      'meta-data': [{ $: { 'android:name': 'android.accessibilityservice', 'android:resource': '@xml/handpilot_accessibility_service' } }],
    });

    ensureService(TRACKING_SERVICE, {
      $: {
        'android:name': TRACKING_SERVICE,
        'android:exported': 'false',
        'android:foregroundServiceType': 'camera',
      },
    });
    return mod;
  });

  config = withStringsXml(config, (mod) => {
    const strings = mod.modResults.resources.string ?? [];
    const values = {
      handpilot_accessibility_label: 'HandPilot hand controls',
      handpilot_accessibility_description:
        'With your permission, HandPilot uses hand gestures to perform taps, swipes, and supported Android navigation actions. It does not read screen content.',
    };
    for (const [name, value] of Object.entries(values)) {
      const entry = strings.find((item) => item.$?.name === name);
      if (entry) entry._ = value;
      else strings.push({ $: { name }, _: value });
    }
    mod.modResults.resources.string = strings;
    return mod;
  });

  config = withDangerousMod(config, [
    'android',
    async (mod) => {
      const xmlDir = path.join(mod.modRequest.platformProjectRoot, 'app', 'src', 'main', 'res', 'xml');
      await fs.mkdir(xmlDir, { recursive: true });
      const serviceXml = `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:description="@string/handpilot_accessibility_description"
    android:accessibilityEventTypes="typeWindowStateChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="150"
    android:canRetrieveWindowContent="false"
    android:canPerformGestures="true" />
`;
      await fs.writeFile(path.join(xmlDir, 'handpilot_accessibility_service.xml'), serviceXml, 'utf8');
      return mod;
    },
  ]);

  return config;
}

module.exports = withHandPilot;
