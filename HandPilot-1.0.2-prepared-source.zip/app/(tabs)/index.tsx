import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  AppState,
  Image,
  PermissionsAndroid,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { HandTrackerPreview } from '@/components/hand-tracker-preview';
import HandPilotModule from '@/modules/handpilot/src/HandPilotModule';
import type {
  HandUpdate,
  LaunchableApp,
  TrackingStatus,
} from '@/modules/handpilot/src/HandPilot.types';

const COLORS = {
  background: '#080C16',
  surface: '#101927',
  surfaceRaised: '#142033',
  border: '#223148',
  white: '#F1F5F8',
  muted: '#8B98AA',
  mint: '#83F7CA',
  amber: '#F4BD72',
  violet: '#A996FF',
  red: '#FF7C82',
};
const SHORTCUTS_KEY = 'handpilot.favorite-apps.v1';
const INITIAL_STATUS: TrackingStatus = {
  cameraPermission: false,
  notificationPermission: false,
  accessibilityEnabled: false,
  tracking: false,
  paused: false,
};

type IconName = React.ComponentProps<typeof Ionicons>['name'];
type PhoneAction = { id: string; label: string; icon: IconName; detail: string };
const PHONE_ACTIONS: PhoneAction[] = [
  { id: 'back', label: 'Back', icon: 'arrow-back-outline', detail: 'Return to the previous screen' },
  { id: 'home', label: 'Home', icon: 'home-outline', detail: 'Go to the home screen' },
  { id: 'recents', label: 'Recent apps', icon: 'albums-outline', detail: 'Switch between recent apps' },
  { id: 'notifications', label: 'Notifications', icon: 'notifications-outline', detail: 'Open notifications' },
  { id: 'quickSettings', label: 'Quick settings', icon: 'options-outline', detail: 'Open Quick Settings' },
  { id: 'screenshot', label: 'Screenshot', icon: 'scan-outline', detail: 'Save a screenshot when supported' },
  { id: 'lock', label: 'Lock screen', icon: 'lock-closed-outline', detail: 'Lock the phone when supported' },
  { id: 'powerMenu', label: 'Power menu', icon: 'power-outline', detail: 'Open Android power controls' },
];
const GESTURE_GUIDE: Array<{ title: string; detail: string; icon: IconName }> = [
  { title: 'Open palm', detail: 'Hold still to show or hide the pointer. Hold again to resume after a fist-pause.', icon: 'hand-left-outline' },
  { title: 'Pinch and release', detail: 'Tap at the pointer. Keep the pinch still to long-press.', icon: 'finger-print-outline' },
  { title: 'Pinch and move', detail: 'Drag along the hand path, then release.', icon: 'move-outline' },
  { title: 'Quick hand sweep', detail: 'Left requests Back; right swipes; up or down scrolls where the current app allows it.', icon: 'swap-horizontal-outline' },
  { title: 'Two hands', detail: 'Move both hands closer or farther apart to request a pinch zoom.', icon: 'resize-outline' },
  { title: 'Closed fist', detail: 'Pause new gesture commands. Open your palm and hold to resume.', icon: 'hand-left-outline' },
];

export default function HomeScreen() {
  const [status, setStatus] = useState(INITIAL_STATUS);
  const [update, setUpdate] = useState<HandUpdate | null>(null);
  const [apps, setApps] = useState<LaunchableApp[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [sensitivity, setSensitivity] = useState(1);
  const [smoothing, setSmoothing] = useState(0.62);
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [showAllCommands, setShowAllCommands] = useState(false);

  const showNotice = useCallback((message: string) => {
    setNotice(message);
    setTimeout(() => setNotice((current) => (current === message ? '' : current)), 4200);
  }, []);

  const refreshStatus = useCallback(async () => {
    if (Platform.OS !== 'android') return;
    try {
      const next = HandPilotModule.getStatus();
      setStatus(next);
      if (next.accessibilityEnabled) {
        const available = await HandPilotModule.getLaunchableApps();
        setApps(available);
      }
    } catch {
      showNotice('Android controls are available in the installed APK.');
    }
  }, [showNotice]);

  useEffect(() => {
    void refreshStatus();
    void AsyncStorage.getItem(SHORTCUTS_KEY).then((value) => {
      if (value) {
        try {
          const parsed: unknown = JSON.parse(value);
          if (Array.isArray(parsed) && parsed.every((item) => typeof item === 'string')) setFavorites(parsed);
        } catch {
          void AsyncStorage.removeItem(SHORTCUTS_KEY);
        }
      }
    });

    const handSubscription = HandPilotModule.addListener('onHandUpdate', (event) => setUpdate(event));
    const trackingSubscription = HandPilotModule.addListener('onTrackingState', (event) => {
      if (event.state === 'tracking') setStatus((current) => ({ ...current, tracking: true, paused: false }));
      if (event.state === 'paused') setStatus((current) => ({ ...current, paused: true }));
      if (event.state === 'stopped' || event.state === 'idle') {
        setStatus((current) => ({ ...current, tracking: false, paused: false }));
        setUpdate(null);
      }
      if (event.message && event.state !== 'tracking') showNotice(event.message);
      void refreshStatus();
    });
    const commandSubscription = HandPilotModule.addListener('onCommand', (event) => {
      if (event.accepted) showNotice(`${event.command} · command sent`);
      else if (event.message) showNotice(event.message);
    });
    const appStateSubscription = AppState.addEventListener('change', (next) => {
      if (next === 'active') setTimeout(() => void refreshStatus(), 450);
    });
    return () => {
      handSubscription.remove();
      trackingSubscription.remove();
      commandSubscription.remove();
      appStateSubscription.remove();
    };
  }, [refreshStatus, showNotice]);

  useEffect(() => {
    HandPilotModule.setControlOptions(sensitivity, smoothing);
  }, [sensitivity, smoothing]);

  const sortedApps = useMemo(() => {
    const favoriteSet = new Set(favorites);
    return [...apps].sort((a, b) => Number(favoriteSet.has(b.packageName)) - Number(favoriteSet.has(a.packageName)) || a.label.localeCompare(b.label));
  }, [apps, favorites]);
  const displayedApps = sortedApps.slice(0, 12);
  const nativeReady = Platform.OS === 'android';
  const cameraVisible = nativeReady && status.tracking && status.cameraPermission;
  const trackingLabel = status.paused ? 'PAUSED' : status.tracking ? 'TRACKING' : 'STANDBY';
  const trackingColor = status.paused ? COLORS.amber : status.tracking ? COLORS.mint : COLORS.muted;

  const startTracking = useCallback(async () => {
    if (Platform.OS !== 'android') {
      showNotice('Install the Android APK to use the camera and phone-wide controls.');
      return;
    }
    setBusy(true);
    try {
      let cameraGranted = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA);
      if (!cameraGranted) {
        cameraGranted = (await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.CAMERA, {
          title: 'Allow HandPilot camera access',
          message: 'HandPilot uses the front camera to detect hand landmarks on this phone. Frames are not recorded or uploaded.',
          buttonPositive: 'Allow camera',
          buttonNegative: 'Not now',
        })) === PermissionsAndroid.RESULTS.GRANTED;
      }
      if (!cameraGranted) {
        showNotice('Camera access is needed for live hand tracking.');
        return;
      }
      if (Number(Platform.Version) >= 33) {
        const notificationGranted = (await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS, {
          title: 'Keep tracking visible',
          message: 'Android shows an ongoing notification while camera tracking is active outside HandPilot.',
          buttonPositive: 'Allow notifications',
          buttonNegative: 'Not now',
        })) === PermissionsAndroid.RESULTS.GRANTED;
        if (!notificationGranted) {
          showNotice('Allow notifications to keep background camera tracking visibly indicated.');
          return;
        }
      }
      await HandPilotModule.startTracking();
      await refreshStatus();
      showNotice(status.accessibilityEnabled ? 'Camera tracking started on-device.' : 'Tracking started. Enable Accessibility for phone-wide control.');
    } catch (error) {
      showNotice(error instanceof Error ? error.message : 'Could not start camera tracking.');
    } finally {
      setBusy(false);
    }
  }, [refreshStatus, showNotice, status.accessibilityEnabled]);

  const stopTracking = useCallback(() => {
    HandPilotModule.stopTracking();
    setStatus((current) => ({ ...current, tracking: false, paused: false }));
    setUpdate(null);
    showNotice('Camera tracking stopped.');
  }, [showNotice]);

  const enableAccessibility = useCallback(() => {
    if (!nativeReady) {
      showNotice('Accessibility setup is available in the Android APK.');
      return;
    }
    HandPilotModule.openAccessibilitySettings();
    showNotice('In Android Settings, enable “HandPilot hand controls”, then return here.');
  }, [nativeReady, showNotice]);

  const runPhoneAction = useCallback(async (action: string, label: string) => {
    if (!status.accessibilityEnabled) {
      showNotice('Enable HandPilot in Android Accessibility settings first.');
      return;
    }
    const accepted = await HandPilotModule.performGlobalAction(action);
    if (!accepted) showNotice(`${label} is not available on this Android version or screen.`);
  }, [showNotice, status.accessibilityEnabled]);

  const toggleFavorite = useCallback((packageName: string) => {
    setFavorites((current) => {
      const next = current.includes(packageName) ? current.filter((item) => item !== packageName) : [...current, packageName];
      void AsyncStorage.setItem(SHORTCUTS_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const launchApp = useCallback(async (app: LaunchableApp) => {
    const launched = await HandPilotModule.launchApp(app.packageName);
    if (!launched) showNotice(`Could not open ${app.label}.`);
  }, [showNotice]);

  const adjustSensitivity = (delta: number) => setSensitivity((value) => Math.max(0.65, Math.min(1.45, Number((value + delta).toFixed(2)))));
  const adjustSmoothing = (delta: number) => setSmoothing((value) => Math.max(0.15, Math.min(0.82, Number((value + delta).toFixed(2)))));

  return (
    <SafeAreaView edges={['top', 'left', 'right']} style={styles.safeArea}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.brand}>
            <Image source={require('@/assets/images/icon.png')} style={styles.brandIcon} />
            <View>
              <Text style={styles.brandName}>HANDPILOT</Text>
              <Text style={styles.brandCaption}>AIR CONTROL / ANDROID</Text>
            </View>
          </View>
          <View style={styles.headerStatus}>
            <View style={[styles.statusDot, { backgroundColor: trackingColor }]} />
            <Text style={[styles.headerStatusText, { color: trackingColor }]}>{trackingLabel}</Text>
          </View>
        </View>

        <View style={styles.hero}>
          <Text style={styles.eyebrow}>HANDS-FREE CONTROL SYSTEM</Text>
          <Text style={styles.headline}>Move naturally.{"\n"}Your phone follows.</Text>
          <Text style={styles.subhead}>A camera-tracked pointer with Android actions, built for steady, deliberate gestures.</Text>
        </View>

        <View style={styles.previewHeader}>
          <View style={styles.sectionTag}>
            <View style={[styles.liveDot, { backgroundColor: cameraVisible ? COLORS.mint : COLORS.amber }]} />
            <Text style={styles.sectionTagText}>{cameraVisible ? 'LIVE · ON-DEVICE' : 'TRACKING VIEW'}</Text>
          </View>
          <Text style={styles.previewMeta}>{update?.hands.length ? `${update.hands.length} HAND${update.hands.length > 1 ? 'S' : ''}` : '21-POINT LANDMARKS'}</Text>
        </View>

        <HandTrackerPreview update={update} cameraReady={cameraVisible} />

        <View style={styles.previewFooter}>
          <View style={styles.handReadout}>
            <Ionicons name="aperture-outline" size={16} color={cameraVisible ? COLORS.mint : COLORS.amber} />
            <Text style={styles.handReadoutText}>{cameraVisible ? update?.hands.length ? 'HAND LOCKED' : 'LOOKING FOR A HAND' : nativeReady ? 'CAMERA STANDBY' : 'ANDROID BUILD PREVIEW'}</Text>
          </View>
          <Text style={styles.gestureReadout}>{update?.gesture?.toUpperCase() ?? 'READY WHEN YOU ARE'}</Text>
        </View>

        {!status.accessibilityEnabled && (
          <View style={styles.setupCard}>
            <View style={styles.setupIcon}><Ionicons name="accessibility-outline" size={20} color={COLORS.violet} /></View>
            <View style={styles.setupCopy}>
              <Text style={styles.cardEyebrow}>PHONE-WIDE CONTROL</Text>
              <Text style={styles.cardTitle}>Enable Android Accessibility</Text>
              <Text style={styles.cardBody}>Allow HandPilot to send touch gestures and supported system actions. It does not read screen content.</Text>
              <Pressable onPress={enableAccessibility} style={({ pressed }) => [styles.inlineButton, pressed && styles.pressed]}>
                <Text style={styles.inlineButtonText}>OPEN ACCESSIBILITY SETTINGS</Text>
                <Ionicons name="arrow-forward" size={14} color={COLORS.mint} />
              </Pressable>
            </View>
          </View>
        )}

        <Pressable
          onPress={status.tracking ? stopTracking : startTracking}
          disabled={busy}
          style={({ pressed }) => [styles.primaryButton, status.tracking && styles.stopButton, pressed && styles.primaryPressed, busy && styles.disabledButton]}
        >
          {busy ? <ActivityIndicator color={status.tracking ? COLORS.white : COLORS.background} /> : <Ionicons name={status.tracking ? 'stop-circle-outline' : 'scan-outline'} size={21} color={status.tracking ? COLORS.white : COLORS.background} />}
          <Text style={[styles.primaryButtonText, status.tracking && styles.stopButtonText]}>{busy ? 'PREPARING CAMERA…' : status.tracking ? 'STOP CAMERA TRACKING' : 'START HAND CONTROL'}</Text>
          {!busy && <Ionicons name={status.tracking ? 'close' : 'arrow-up-right-box'} size={18} color={status.tracking ? COLORS.white : COLORS.background} />}
        </Pressable>

        <View style={styles.permissionStrip}>
          <Ionicons name="shield-checkmark-outline" size={16} color={COLORS.mint} />
          <Text style={styles.permissionText}>Camera stays on-device. A visible notification remains while background tracking is active.</Text>
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={styles.eyebrow}>SYSTEM SHORTCUTS</Text>
            <Text style={styles.sectionTitle}>Phone controls</Text>
          </View>
          <Text style={styles.sectionCount}>ANDROID</Text>
        </View>
        <View style={styles.actionsGrid}>
          {PHONE_ACTIONS.map((action) => (
            <Pressable
              key={action.id}
              onPress={() => void runPhoneAction(action.id, action.label)}
              style={({ pressed }) => [styles.actionCard, pressed && styles.actionPressed, !status.accessibilityEnabled && styles.actionMuted]}
              accessibilityRole="button"
              accessibilityLabel={`${action.label}. ${action.detail}`}
            >
              <View style={styles.actionIcon}><Ionicons name={action.icon} size={19} color={status.accessibilityEnabled ? COLORS.mint : COLORS.muted} /></View>
              <View style={styles.actionCopy}>
                <Text style={styles.actionLabel}>{action.label}</Text>
                <Text style={styles.actionDetail} numberOfLines={1}>{action.detail}</Text>
              </View>
          <Ionicons name="arrow-up-right-box" size={14} color="#607087" />
            </Pressable>
          ))}
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={styles.eyebrow}>POINTER TUNING</Text>
            <Text style={styles.sectionTitle}>Make it feel right</Text>
          </View>
          <Pressable onPress={() => { HandPilotModule.calibrate(); showNotice('Calibration set. Hold your hand naturally in the camera frame.'); }} style={styles.calibrateButton}>
            <Ionicons name="locate-outline" size={15} color={COLORS.mint} />
            <Text style={styles.calibrateText}>CALIBRATE</Text>
          </Pressable>
        </View>

        <View style={styles.tuningCard}>
          <TuningRow label="POINTER RANGE" value={sensitivity.toFixed(2)} fill={(sensitivity - 0.65) / 0.8} onMinus={() => adjustSensitivity(-0.1)} onPlus={() => adjustSensitivity(0.1)} />
          <View style={styles.tuningDivider} />
          <TuningRow label="MOTION SMOOTHING" value={`${Math.round(smoothing * 100)}%`} fill={(smoothing - 0.15) / 0.67} onMinus={() => adjustSmoothing(-0.08)} onPlus={() => adjustSmoothing(0.08)} />
          <Text style={styles.tuningNote}>Higher smoothing steadies the pointer but adds a little lag. Calibrate again after changing your camera position.</Text>
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={styles.eyebrow}>YOUR LAUNCH SHELF</Text>
            <Text style={styles.sectionTitle}>Favorite apps</Text>
          </View>
          <Text style={styles.sectionCount}>{favorites.length} SAVED</Text>
        </View>
        {!status.accessibilityEnabled ? (
          <View style={styles.emptyShelf}>
            <Ionicons name="apps-outline" size={19} color={COLORS.muted} />
            <Text style={styles.emptyShelfText}>Enable phone controls to choose apps installed on this device.</Text>
          </View>
        ) : displayedApps.length === 0 ? (
          <View style={styles.emptyShelf}><Text style={styles.emptyShelfText}>No launchable apps were found.</Text></View>
        ) : (
          <View style={styles.appGrid}>
            {displayedApps.map((app) => {
              const favorite = favorites.includes(app.packageName);
              return (
                <View key={app.packageName} style={styles.appCard}>
                  <Pressable onPress={() => void launchApp(app)} style={({ pressed }) => [styles.appLaunch, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`Open ${app.label}`}>
                    <View style={styles.appMark}><Ionicons name="apps-outline" size={19} color={COLORS.violet} /></View>
                    <Text style={styles.appLabel} numberOfLines={1}>{app.label}</Text>
                  </Pressable>
                  <Pressable onPress={() => toggleFavorite(app.packageName)} style={styles.favoriteButton} accessibilityLabel={favorite ? `Remove ${app.label} from favorites` : `Add ${app.label} to favorites`}>
                    <Ionicons name={favorite ? 'star' : 'star-outline'} size={15} color={favorite ? COLORS.amber : COLORS.muted} />
                  </Pressable>
                </View>
              );
            })}
          </View>
        )}

        <View style={styles.sectionHeading}>
          <View>
            <Text style={styles.eyebrow}>AIR COMMANDS</Text>
            <Text style={styles.sectionTitle}>Gesture guide</Text>
          </View>
          <Pressable onPress={() => setShowAllCommands((value) => !value)} style={styles.guideToggle}>
            <Text style={styles.guideToggleText}>{showAllCommands ? 'LESS' : 'ALL COMMANDS'}</Text>
            <Ionicons name={showAllCommands ? 'chevron-up' : 'chevron-down'} size={14} color={COLORS.mint} />
          </Pressable>
        </View>
        <View style={styles.guideCard}>
          {(showAllCommands ? GESTURE_GUIDE : GESTURE_GUIDE.slice(0, 4)).map((item, index, array) => (
            <View key={item.title} style={[styles.guideRow, index === array.length - 1 && styles.noBorder]}>
              <View style={styles.guideIcon}><Ionicons name={item.icon} size={17} color={index === 0 ? COLORS.mint : COLORS.violet} /></View>
              <View style={styles.guideCopy}>
                <Text style={styles.guideTitle}>{item.title}</Text>
                <Text style={styles.guideDetail}>{item.detail}</Text>
              </View>
              <Text style={styles.guideIndex}>{String(index + 1).padStart(2, '0')}</Text>
            </View>
          ))}
        </View>

        <View style={styles.limitNote}>
          <Ionicons name="information-circle-outline" size={19} color={COLORS.amber} />
          <View style={styles.limitCopy}>
            <Text style={styles.limitTitle}>Control depends on Android and the app in front.</Text>
            <Text style={styles.limitDetail}>Calibration, lighting and camera angle affect precision. The phone must be awake and unlocked. Secure or protected screens may block gestures. No app can bypass your PIN or biometric lock.</Text>
          </View>
        </View>

        {notice.length > 0 && (
          <View style={styles.toast}>
            <View style={styles.toastAccent} />
            <Text style={styles.toastText}>{notice}</Text>
            <Pressable onPress={() => setNotice('')} hitSlop={10}><Ionicons name="close" size={17} color={COLORS.muted} /></Pressable>
          </View>
        )}
        <View style={styles.footer}>
          <Text style={styles.footerText}>HANDPILOT 01</Text>
          <Text style={styles.footerText}>PRIVATE BY DESIGN · BUILT FOR ANDROID</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function TuningRow({ label, value, fill, onMinus, onPlus }: { label: string; value: string; fill: number; onMinus: () => void; onPlus: () => void }) {
  return (
    <View style={styles.tuningRow}>
      <View style={styles.tuningTop}>
        <Text style={styles.tuningLabel}>{label}</Text>
        <Text style={styles.tuningValue}>{value}</Text>
      </View>
      <View style={styles.tuningControls}>
        <Pressable onPress={onMinus} style={styles.stepButton} accessibilityLabel={`Decrease ${label}`}><Ionicons name="remove" size={16} color={COLORS.white} /></Pressable>
        <View style={styles.trackBar}><View style={[styles.trackFill, { width: `${Math.max(4, Math.min(100, fill * 100))}%` }]} /></View>
        <Pressable onPress={onPlus} style={styles.stepButton} accessibilityLabel={`Increase ${label}`}><Ionicons name="add" size={16} color={COLORS.white} /></Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  scroll: { flex: 1, backgroundColor: COLORS.background },
  content: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 34, maxWidth: 650, width: '100%', alignSelf: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandIcon: { width: 38, height: 38, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border },
  brandName: { color: COLORS.white, fontSize: 14, fontWeight: '800', letterSpacing: 2.2 },
  brandCaption: { color: COLORS.muted, fontSize: 8, fontWeight: '700', letterSpacing: 1.4, marginTop: 3 },
  headerStatus: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 15, backgroundColor: '#111A28', borderWidth: 1, borderColor: '#202D40' },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  headerStatusText: { fontSize: 9, fontWeight: '800', letterSpacing: 1.1 },
  hero: { marginBottom: 20 },
  eyebrow: { color: COLORS.mint, fontSize: 9, fontWeight: '800', letterSpacing: 1.6 },
  headline: { color: COLORS.white, fontSize: 33, lineHeight: 39, letterSpacing: -1.1, fontWeight: '800', marginTop: 9 },
  subhead: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginTop: 9, maxWidth: 320 },
  previewHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 9 },
  sectionTag: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  liveDot: { width: 6, height: 6, borderRadius: 4 },
  sectionTagText: { color: COLORS.white, fontSize: 9, fontWeight: '800', letterSpacing: 1.2 },
  previewMeta: { color: '#718096', fontSize: 8, fontWeight: '700', letterSpacing: 1.1 },
  previewFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 11, marginBottom: 19 },
  handReadout: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  handReadoutText: { color: COLORS.white, fontSize: 9, fontWeight: '700', letterSpacing: 0.7 },
  gestureReadout: { color: COLORS.muted, fontSize: 8, fontWeight: '700', letterSpacing: 0.7, maxWidth: '52%' },
  setupCard: { flexDirection: 'row', gap: 12, padding: 15, borderRadius: 18, borderWidth: 1, borderColor: '#40395E', backgroundColor: '#15172A', marginBottom: 14 },
  setupIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: 'rgba(169,150,255,0.11)', alignItems: 'center', justifyContent: 'center' },
  setupCopy: { flex: 1 },
  cardEyebrow: { color: COLORS.violet, fontSize: 8, fontWeight: '800', letterSpacing: 1.4 },
  cardTitle: { color: COLORS.white, fontSize: 15, fontWeight: '700', marginTop: 5 },
  cardBody: { color: COLORS.muted, fontSize: 11, lineHeight: 16, marginTop: 5 },
  inlineButton: { flexDirection: 'row', alignItems: 'center', gap: 7, marginTop: 12, alignSelf: 'flex-start' },
  inlineButtonText: { color: COLORS.mint, fontSize: 8, fontWeight: '800', letterSpacing: 1.1 },
  primaryButton: { minHeight: 55, backgroundColor: COLORS.mint, borderRadius: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, marginBottom: 11 },
  stopButton: { backgroundColor: '#542C37', borderWidth: 1, borderColor: '#79404B' },
  primaryPressed: { opacity: 0.83, transform: [{ scale: 0.99 }] },
  disabledButton: { opacity: 0.7 },
  primaryButtonText: { flex: 1, marginHorizontal: 11, color: COLORS.background, fontSize: 11, fontWeight: '900', letterSpacing: 1.1 },
  stopButtonText: { color: COLORS.white },
  permissionStrip: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, paddingHorizontal: 4, marginBottom: 29 },
  permissionText: { flex: 1, color: COLORS.muted, fontSize: 10, lineHeight: 15 },
  sectionHeading: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 12, marginTop: 3 },
  sectionTitle: { color: COLORS.white, fontSize: 21, fontWeight: '700', letterSpacing: -0.4, marginTop: 4 },
  sectionCount: { color: '#738197', fontSize: 8, fontWeight: '800', letterSpacing: 1.1, marginBottom: 3 },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 9, marginBottom: 27 },
  actionCard: { width: '48.4%', minHeight: 70, backgroundColor: COLORS.surface, borderColor: COLORS.border, borderWidth: 1, borderRadius: 15, paddingHorizontal: 10, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  actionPressed: { backgroundColor: '#17243A', borderColor: '#53647D' },
  actionMuted: { opacity: 0.72 },
  actionIcon: { width: 30, height: 30, borderRadius: 10, backgroundColor: '#182437', alignItems: 'center', justifyContent: 'center' },
  actionCopy: { flex: 1, minWidth: 0 },
  actionLabel: { color: COLORS.white, fontSize: 10, fontWeight: '700' },
  actionDetail: { color: COLORS.muted, fontSize: 8, marginTop: 4 },
  calibrateButton: { flexDirection: 'row', gap: 6, alignItems: 'center', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 11, backgroundColor: '#10271F', borderWidth: 1, borderColor: '#245340' },
  calibrateText: { color: COLORS.mint, fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  tuningCard: { padding: 15, borderRadius: 18, backgroundColor: COLORS.surface, borderColor: COLORS.border, borderWidth: 1, marginBottom: 27 },
  tuningRow: { gap: 11 },
  tuningTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  tuningLabel: { color: COLORS.muted, fontSize: 8, fontWeight: '800', letterSpacing: 1.15 },
  tuningValue: { color: COLORS.white, fontSize: 11, fontWeight: '700', fontVariant: ['tabular-nums'] },
  tuningControls: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  stepButton: { width: 28, height: 28, borderRadius: 9, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.surfaceRaised, borderWidth: 1, borderColor: '#304057' },
  trackBar: { flex: 1, height: 4, borderRadius: 3, backgroundColor: '#26344A', overflow: 'hidden' },
  trackFill: { height: 4, borderRadius: 3, backgroundColor: COLORS.mint },
  tuningDivider: { height: 1, backgroundColor: COLORS.border, marginVertical: 14 },
  tuningNote: { color: '#78869A', fontSize: 9, lineHeight: 14, marginTop: 13 },
  emptyShelf: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 15, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 16, marginBottom: 27 },
  emptyShelfText: { color: COLORS.muted, fontSize: 10, lineHeight: 15, flex: 1 },
  appGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 27 },
  appCard: { width: '31.7%', minHeight: 74, flexDirection: 'row', backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 15, alignItems: 'center', paddingHorizontal: 8 },
  appLaunch: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4, height: 72 },
  appMark: { width: 32, height: 32, borderRadius: 11, backgroundColor: '#211D37', alignItems: 'center', justifyContent: 'center' },
  appLabel: { color: COLORS.white, maxWidth: 72, fontSize: 8, fontWeight: '700' },
  favoriteButton: { padding: 7, alignSelf: 'flex-start', marginTop: 3 },
  guideToggle: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 4 },
  guideToggleText: { color: COLORS.mint, fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  guideCard: { borderRadius: 18, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 13, marginBottom: 18 },
  guideRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, borderBottomWidth: 1, borderColor: '#1D2A3C' },
  noBorder: { borderBottomWidth: 0 },
  guideIcon: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: '#192338' },
  guideCopy: { flex: 1 },
  guideTitle: { color: COLORS.white, fontSize: 11, fontWeight: '700' },
  guideDetail: { color: COLORS.muted, fontSize: 9, lineHeight: 14, marginTop: 3 },
  guideIndex: { color: '#5B6B81', fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  limitNote: { flexDirection: 'row', gap: 9, padding: 13, borderRadius: 15, backgroundColor: '#211C17', borderWidth: 1, borderColor: '#403324', marginBottom: 20 },
  limitCopy: { flex: 1 },
  limitTitle: { color: '#F4D6A6', fontSize: 10, fontWeight: '700', lineHeight: 15 },
  limitDetail: { color: '#B2A08A', fontSize: 9, lineHeight: 14, marginTop: 5 },
  toast: { flexDirection: 'row', alignItems: 'center', gap: 9, minHeight: 43, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 13, backgroundColor: '#152237', borderWidth: 1, borderColor: '#354761', marginBottom: 16 },
  toastAccent: { width: 3, height: 20, borderRadius: 2, backgroundColor: COLORS.mint },
  toastText: { flex: 1, color: COLORS.white, fontSize: 10, lineHeight: 15 },
  footer: { paddingTop: 14, borderTopWidth: 1, borderTopColor: '#1D293A', flexDirection: 'row', justifyContent: 'space-between' },
  footerText: { color: '#5E6B7E', fontSize: 7, letterSpacing: 1, fontWeight: '800' },
  pressed: { opacity: 0.75 },
});
