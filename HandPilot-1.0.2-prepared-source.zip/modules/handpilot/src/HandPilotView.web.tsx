import { View, Text, StyleSheet } from 'react-native';
import type { HandPilotViewProps } from './HandPilot.types';

export default function HandPilotView(_props: HandPilotViewProps) {
  return (
    <View style={styles.stage} accessibilityLabel="Android-only live camera preview">
      <View style={styles.ring} />
      <View style={styles.target}>
        <View style={styles.crosshairH} />
        <View style={styles.crosshairV} />
      </View>
      <Text style={styles.kicker}>NATIVE CAMERA VIEW</Text>
      <Text style={styles.title}>Live tracking starts on Android</Text>
      <Text style={styles.copy}>This web preview does not access your camera or emulate hand detection.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  stage: { flex: 1, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', borderRadius: 26, backgroundColor: '#0C1422', paddingHorizontal: 24 },
  ring: { position: 'absolute', width: 210, height: 210, borderRadius: 105, borderWidth: 1, borderColor: 'rgba(118,255,204,0.15)' },
  target: { width: 64, height: 64, borderRadius: 32, borderWidth: 1, borderColor: 'rgba(118,255,204,0.7)', alignItems: 'center', justifyContent: 'center', marginBottom: 26 },
  crosshairH: { position: 'absolute', width: 90, height: 1, backgroundColor: 'rgba(118,255,204,0.24)' },
  crosshairV: { position: 'absolute', height: 90, width: 1, backgroundColor: 'rgba(118,255,204,0.24)' },
  kicker: { color: '#82F4C9', fontSize: 10, fontWeight: '700', letterSpacing: 2 },
  title: { marginTop: 10, color: '#F3F7FA', fontSize: 17, fontWeight: '700', textAlign: 'center' },
  copy: { marginTop: 8, maxWidth: 250, color: '#8492A6', fontSize: 12, lineHeight: 18, textAlign: 'center' },
});
