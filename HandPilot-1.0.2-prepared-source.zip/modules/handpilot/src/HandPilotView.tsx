import { requireNativeView } from 'expo';
import type { HandPilotViewProps } from './HandPilot.types';

const NativeHandPilotView = requireNativeView<HandPilotViewProps>('HandPilot');

export default function HandPilotView(props: HandPilotViewProps) {
  return <NativeHandPilotView {...props} />;
}
