import { NativeModule, registerWebModule } from 'expo';
import type {
  CommandEvent,
  HandPilotModuleEvents,
  LaunchableApp,
  TrackingStateEvent,
  TrackingStatus,
} from './HandPilot.types';

class HandPilotWebModule extends NativeModule<HandPilotModuleEvents> {
  getStatus(): TrackingStatus {
    return {
      cameraPermission: false,
      notificationPermission: false,
      accessibilityEnabled: false,
      tracking: false,
      paused: false,
    };
  }
  openAccessibilitySettings(): void {}
  async startTracking(): Promise<boolean> { return false; }
  stopTracking(): void {}
  setControlOptions(_sensitivity: number, _smoothing: number): void {}
  calibrate(): void {}
  async performGlobalAction(_action: string): Promise<boolean> { return false; }
  async getLaunchableApps(): Promise<LaunchableApp[]> { return []; }
  async launchApp(_packageName: string): Promise<boolean> { return false; }
}

export type { CommandEvent, TrackingStateEvent };
export default registerWebModule(HandPilotWebModule, 'HandPilot');
