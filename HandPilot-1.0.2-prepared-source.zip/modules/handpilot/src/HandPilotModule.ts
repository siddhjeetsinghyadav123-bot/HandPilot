import { NativeModule, requireNativeModule } from 'expo';
import type {
  CommandEvent,
  HandPilotModuleEvents,
  LaunchableApp,
  TrackingStateEvent,
  TrackingStatus,
} from './HandPilot.types';

declare class HandPilotNativeModule extends NativeModule<HandPilotModuleEvents> {
  getStatus(): TrackingStatus;
  openAccessibilitySettings(): void;
  startTracking(): Promise<boolean>;
  stopTracking(): void;
  setControlOptions(sensitivity: number, smoothing: number): void;
  calibrate(): void;
  performGlobalAction(action: string): Promise<boolean>;
  getLaunchableApps(): Promise<LaunchableApp[]>;
  launchApp(packageName: string): Promise<boolean>;
}

const HandPilotModule = requireNativeModule<HandPilotNativeModule>('HandPilot');
export type { CommandEvent, TrackingStateEvent };
export default HandPilotModule;
