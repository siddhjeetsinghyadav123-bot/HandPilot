import type { StyleProp, ViewStyle } from 'react-native';

export type Landmark = { x: number; y: number; z: number };
export type HandPointer = { x: number; y: number; screenX: number; screenY: number };
export type HandUpdate = {
  hands: Landmark[][];
  pointer: HandPointer | null;
  gesture: string;
  pointerVisible: boolean;
  paused: boolean;
  tracking: boolean;
};
export type TrackingStatus = {
  cameraPermission: boolean;
  notificationPermission: boolean;
  accessibilityEnabled: boolean;
  tracking: boolean;
  paused: boolean;
};
export type LaunchableApp = { label: string; packageName: string };
export type TrackingStateEvent = {
  state: 'idle' | 'starting' | 'tracking' | 'paused' | 'stopped' | 'error';
  message?: string;
};
export type CommandEvent = { command: string; accepted: boolean; message?: string };

export type HandPilotModuleEvents = {
  onTrackingState: (event: TrackingStateEvent) => void;
  onHandUpdate: (event: HandUpdate) => void;
  onCommand: (event: CommandEvent) => void;
};

export type HandPilotViewProps = {
  style?: StyleProp<ViewStyle>;
};
