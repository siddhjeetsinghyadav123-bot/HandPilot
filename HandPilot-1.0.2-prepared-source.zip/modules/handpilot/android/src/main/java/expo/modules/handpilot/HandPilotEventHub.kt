package expo.modules.handpilot

import android.os.Handler
import android.os.Looper

object HandPilotEventHub {
  private val mainHandler = Handler(Looper.getMainLooper())
  @Volatile var eventSink: ((String, Map<String, Any?>) -> Unit)? = null

  fun emit(eventName: String, payload: Map<String, Any?> = emptyMap()) {
    mainHandler.post {
      eventSink?.invoke(eventName, payload)
    }
  }
}
