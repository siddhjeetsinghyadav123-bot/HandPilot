package expo.modules.handpilot

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class HandPilotModule : Module() {
  init {
    HandPilotEventHub.eventSink = { eventName, payload -> sendEvent(eventName, payload) }
  }

  override fun definition() = ModuleDefinition {
    Name("HandPilot")
    Events("onTrackingState", "onHandUpdate", "onCommand")

    Function("getStatus") {
      val context = requireContext()
      mapOf(
        "cameraPermission" to HandPilotTrackingService.hasCameraPermission(context),
        "notificationPermission" to HandPilotTrackingService.hasNotificationPermission(context),
        "accessibilityEnabled" to HandPilotAccessibilityService.isEnabled(context),
        "tracking" to HandPilotTrackingService.isRunning,
        "paused" to HandPilotGestureController.isPaused,
      )
    }

    Function("openAccessibilitySettings") {
      val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      requireContext().startActivity(intent)
    }

    AsyncFunction("startTracking") {
      val context = requireContext()
      if (!HandPilotTrackingService.hasCameraPermission(context)) {
        throw IllegalStateException("Allow camera access before starting hand tracking.")
      }
      ContextCompat.startForegroundService(context, Intent(context, HandPilotTrackingService::class.java))
      true
    }

    Function("stopTracking") {
      val context = requireContext()
      context.stopService(Intent(context, HandPilotTrackingService::class.java))
    }

    Function("setControlOptions") { sensitivity: Double, smoothing: Double ->
      HandPilotGestureController.setOptions(sensitivity.toFloat(), smoothing.toFloat())
    }

    Function("calibrate") {
      HandPilotGestureController.calibrate()
    }

    AsyncFunction("performGlobalAction") { action: String ->
      HandPilotAccessibilityService.perform(action)
    }

    AsyncFunction("getLaunchableApps") {
      val context = requireContext()
      val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
      @Suppress("DEPRECATION")
      val activities = context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
      activities
        .asSequence()
        .filter { it.activityInfo.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map {
          mapOf(
            "label" to it.loadLabel(context.packageManager).toString(),
            "packageName" to it.activityInfo.packageName,
          )
        }
        .sortedBy { (it["label"] as String).lowercase() }
        .take(30)
        .toList()
    }

    AsyncFunction("launchApp") { packageName: String ->
      val context = requireContext()
      val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
      if (launchIntent == null) {
        false
      } else {
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        true
      }
    }

    View(HandPilotView::class) {
      Events("onPreviewReady")
    }
  }

  private fun requireContext(): Context = requireNotNull(appContext.reactContext) {
    "HandPilot is not attached to a React context."
  }
}
