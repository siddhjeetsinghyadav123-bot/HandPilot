package expo.modules.handpilot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import kotlin.math.max

class HandPilotAccessibilityService : AccessibilityService() {
  private val mainHandler = Handler(Looper.getMainLooper())
  private var pointerView: View? = null
  private var windowManager: WindowManager? = null

  companion object {
    @Volatile var current: HandPilotAccessibilityService? = null
      private set

    fun isEnabled(context: Context): Boolean {
      val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
      val target = ComponentName(context, HandPilotAccessibilityService::class.java)
      return enabled.split(':').any { ComponentName.unflattenFromString(it) == target }
    }

    fun perform(action: String): Boolean = current?.performNamedAction(action) ?: false

    fun updatePointer(x: Float, y: Float, visible: Boolean) {
      current?.mainHandler?.post { current?.showPointer(x, y, visible) }
    }

    fun dispatchPath(points: List<PointF>, durationMs: Long, label: String): Boolean =
      current?.dispatchPoints(points, durationMs, label) ?: false

    fun dispatchMultiTouch(startA: PointF, startB: PointF, endA: PointF, endB: PointF, durationMs: Long, label: String): Boolean =
      current?.dispatchTwoFinger(startA, startB, endA, endB, durationMs, label) ?: false
  }

  override fun onServiceConnected() {
    super.onServiceConnected()
    current = this
    windowManager = getSystemService(WindowManager::class.java)
    HandPilotEventHub.emit("onTrackingState", mapOf("state" to "tracking", "message" to "Android phone controls are enabled."))
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

  override fun onInterrupt() = Unit

  override fun onDestroy() {
    showPointer(0f, 0f, false)
    if (current === this) current = null
    HandPilotEventHub.emit("onTrackingState", mapOf("state" to "idle", "message" to "Android phone controls are off."))
    super.onDestroy()
  }

  private fun performNamedAction(action: String): Boolean {
    val result = when (action) {
      "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
      "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
      "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
      "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
      "quickSettings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
      "screenshot" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) else false
      "lock" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
      "powerMenu" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
      "mediaToggle" -> performGlobalAction(GLOBAL_ACTION_MEDIA_PLAY_PAUSE)
      else -> false
    }
    HandPilotEventHub.emit("onCommand", mapOf("command" to action, "accepted" to result))
    return result
  }

  private fun dispatchPoints(points: List<PointF>, durationMs: Long, label: String): Boolean {
    if (points.isEmpty()) return false
    val path = Path().apply {
      moveTo(points.first().x, points.first().y)
      if (points.size == 1) lineTo(points.first().x + 1f, points.first().y + 1f)
      else points.drop(1).forEach { lineTo(it.x, it.y) }
    }
    val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(40L, 1600L))
    val gesture = GestureDescription.Builder().addStroke(stroke).build()
    return dispatchGesture(gesture, object : GestureResultCallback() {
      override fun onCompleted(gestureDescription: GestureDescription?) {
        HandPilotEventHub.emit("onCommand", mapOf("command" to label, "accepted" to true))
      }
      override fun onCancelled(gestureDescription: GestureDescription?) {
        HandPilotEventHub.emit("onCommand", mapOf("command" to label, "accepted" to false, "message" to "Android cancelled the touch gesture."))
      }
    }, mainHandler)
  }

  private fun dispatchTwoFinger(startA: PointF, startB: PointF, endA: PointF, endB: PointF, durationMs: Long, label: String): Boolean {
    fun stroke(from: PointF, to: PointF): GestureDescription.StrokeDescription {
      val path = Path().apply { moveTo(from.x, from.y); lineTo(to.x, to.y) }
      return GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(100L, 800L))
    }
    val gesture = GestureDescription.Builder()
      .addStroke(stroke(startA, endA))
      .addStroke(stroke(startB, endB))
      .build()
    val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
      override fun onCompleted(gestureDescription: GestureDescription?) {
        HandPilotEventHub.emit("onCommand", mapOf("command" to label, "accepted" to true))
      }
      override fun onCancelled(gestureDescription: GestureDescription?) {
        HandPilotEventHub.emit("onCommand", mapOf("command" to label, "accepted" to false))
      }
    }, mainHandler)
    return accepted
  }

  private fun showPointer(x: Float, y: Float, visible: Boolean) {
    val wm = windowManager ?: return
    if (!visible) {
      pointerView?.let { runCatching { wm.removeView(it) } }
      pointerView = null
      return
    }
    val diameter = (resources.displayMetrics.density * 34f).toInt().coerceAtLeast(24)
    val view = pointerView ?: View(this).apply {
      background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.argb(34, 112, 255, 203))
        setStroke((resources.displayMetrics.density * 2).toInt().coerceAtLeast(2), Color.rgb(112, 255, 203))
      }
      contentDescription = "HandPilot pointer"
      val params = WindowManager.LayoutParams(
        diameter,
        diameter,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT,
      ).apply { gravity = Gravity.TOP or Gravity.START }
      wm.addView(this, params)
      pointerView = this
      this
    }
    val params = view.layoutParams as? WindowManager.LayoutParams ?: return
    params.x = (x - diameter / 2f).toInt().coerceAtLeast(0)
    params.y = (y - diameter / 2f).toInt().coerceAtLeast(0)
    runCatching { wm.updateViewLayout(view, params) }
  }
}
