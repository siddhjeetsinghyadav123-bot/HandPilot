package expo.modules.handpilot

import android.graphics.Path
import android.graphics.PointF
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

data class Landmark(val x: Float, val y: Float, val z: Float)
data class PointerSnapshot(val x: Float, val y: Float, val screenX: Float, val screenY: Float)
data class ControllerSnapshot(
  val pointer: PointerSnapshot?,
  val gesture: String,
  val pointerVisible: Boolean,
  val paused: Boolean,
)

object HandPilotGestureController {
  @Volatile var isPaused: Boolean = false
    private set
  @Volatile private var sensitivity = 1.0f
  @Volatile private var smoothing = 0.62f
  private var pointerVisible = false
  private var filteredPointer: PointF? = null
  private var calibrationAnchor: PointF? = null
  private var calibrateOnNextFrame = false
  private var lastGesture = "Searching for a hand"
  private var openPose = false
  private var openPoseStartedAt = 0L
  private var openPoseActionDone = false
  private var previousPalm: PointF? = null
  private var previousPalmAt = 0L
  private var lastSwipeAt = 0L
  private var pinchStart: PointF? = null
  private var pinchStartedAt = 0L
  private var pinchSamples = mutableListOf<PointF>()
  private var lastPinchSampleAt = 0L
  private var previousPairDistance: Float? = null
  private var previousPairAt = 0L
  private var fistStartedAt = 0L
  private var previousPairPoints: Pair<Landmark, Landmark>? = null
  private val mainWidth: Float get() = screenMetrics().widthPixels.toFloat()
  private val mainHeight: Float get() = screenMetrics().heightPixels.toFloat()

  @Synchronized
  fun setOptions(nextSensitivity: Float, nextSmoothing: Float) {
    sensitivity = nextSensitivity.coerceIn(0.65f, 1.45f)
    smoothing = nextSmoothing.coerceIn(0.15f, 0.82f)
  }

  @Synchronized
  fun calibrate() {
    calibrateOnNextFrame = true
    HandPilotEventHub.emit("onTrackingState", mapOf("state" to "starting", "message" to "Hold your hand in the center to calibrate."))
  }

  @Synchronized
  fun reset() {
    isPaused = false
    pointerVisible = false
    filteredPointer = null
    pinchStart = null
    pinchSamples.clear()
    previousPalm = null
    previousPairDistance = null
    previousPairPoints = null
    fistStartedAt = 0L
    HandPilotAccessibilityService.updatePointer(0f, 0f, false)
  }

  @Synchronized
  fun process(hands: List<List<Landmark>>): ControllerSnapshot {
    val now = SystemClock.elapsedRealtime()
    if (hands.isEmpty() || hands.first().size < 21) {
      previousPalm = null
      previousPairDistance = null
      openPose = false
      openPoseActionDone = false
      pinchStart = null
      pinchSamples.clear()
      pointerVisible = false
      HandPilotAccessibilityService.updatePointer(0f, 0f, false)
      lastGesture = if (isPaused) "Paused" else "Searching for a hand"
      return ControllerSnapshot(null, lastGesture, false, isPaused)
    }

    val first = hands.first()
    val thumbIndex = distance(first[4], first[8])
    val palmScale = max(distance(first[0], first[9]), 0.045f)
    val pinch = thumbIndex / palmScale < 0.34f
    val extended = listOf(8 to 6, 12 to 10, 16 to 14, 20 to 18)
      .count { (tip, middle) -> distance(first[tip], first[0]) > distance(first[middle], first[0]) * 1.10f }
    val fistPose = extended == 0 && !pinch
    val open = extended >= 3 && !pinch
    val palm = first[9]
    val rawPointer = toRawScreen(first[8])

    if (calibrateOnNextFrame) {
      calibrationAnchor = PointF(rawPointer.x, rawPointer.y)
      calibrateOnNextFrame = false
      HandPilotEventHub.emit("onTrackingState", mapOf("state" to "tracking", "message" to "Center calibration saved."))
    }
    val mapped = toMappedScreen(first[8])
    val previous = filteredPointer
    val alpha = (1f - smoothing).coerceIn(0.16f, 0.82f)
    val smooth = if (previous == null) mapped else PointF(
      previous.x + (mapped.x - previous.x) * alpha,
      previous.y + (mapped.y - previous.y) * alpha,
    )
    filteredPointer = smooth

    if (fistPose) {
      if (fistStartedAt == 0L) fistStartedAt = now
    } else {
      fistStartedAt = 0L
    }
    val fist = fistPose && now - fistStartedAt >= 350L

    if (fist) {
      if (!isPaused) {
        isPaused = true
        pointerVisible = false
        pinchStart = null
        pinchSamples.clear()
        lastGesture = "Paused with fist"
        HandPilotAccessibilityService.updatePointer(0f, 0f, false)
        HandPilotEventHub.emit("onTrackingState", mapOf("state" to "paused", "message" to "Fist detected. Gestures paused."))
      }
      previousPalm = null
      openPose = false
      openPoseActionDone = false
      return snapshot(first, smooth)
    }

    if (isPaused) {
      if (open) {
        if (!openPose) {
          openPose = true
          openPoseStartedAt = now
          openPoseActionDone = false
        } else if (!openPoseActionDone && now - openPoseStartedAt >= 850L) {
          isPaused = false
          openPoseActionDone = true
          pointerVisible = true
          lastGesture = "Resumed with open palm"
          HandPilotEventHub.emit("onTrackingState", mapOf("state" to "tracking", "message" to "Open palm detected. Tracking resumed."))
        }
      } else {
        openPose = false
        openPoseActionDone = false
      }
      previousPalm = PointF(palm.x, palm.y)
      return snapshot(first, smooth)
    }

    if (open) {
      if (!openPose) {
        openPose = true
        openPoseStartedAt = now
        openPoseActionDone = false
        previousPalm = PointF(palm.x, palm.y)
        previousPalmAt = now
      } else if (!openPoseActionDone && now - openPoseStartedAt >= 600L) {
        pointerVisible = !pointerVisible
        openPoseActionDone = true
        lastGesture = if (pointerVisible) "Pointer shown" else "Pointer hidden"
        HandPilotEventHub.emit("onCommand", mapOf("command" to lastGesture, "accepted" to true))
      }
      if (previousPalm != null) detectSwipe(palm, now)
    } else {
      openPose = false
      openPoseActionDone = false
      previousPalm = PointF(palm.x, palm.y)
      previousPalmAt = now
    }

    if (pinch) {
      if (pinchStart == null) {
        pinchStart = PointF(smooth.x, smooth.y)
        pinchStartedAt = now
        pinchSamples = mutableListOf(PointF(smooth.x, smooth.y))
        lastPinchSampleAt = now
      } else if (now - lastPinchSampleAt >= 28L) {
        pinchSamples.add(PointF(smooth.x, smooth.y))
        lastPinchSampleAt = now
      }
      lastGesture = "Pinch held"
    } else if (pinchStart != null) {
      finishPinch(smooth, now)
    }

    if (hands.size >= 2 && hands[1].size >= 21 && !pinch) detectTwoHandZoom(first, hands[1], now)
    if (pointerVisible) HandPilotAccessibilityService.updatePointer(smooth.x, smooth.y, true)
    else HandPilotAccessibilityService.updatePointer(0f, 0f, false)

    return snapshot(first, smooth)
  }

  private fun snapshot(hand: List<Landmark>, point: PointF): ControllerSnapshot {
    val w = max(mainWidth, 1f)
    val h = max(mainHeight, 1f)
    val mirrorX = (1f - hand[8].x).coerceIn(0f, 1f)
    return ControllerSnapshot(
      PointerSnapshot(mirrorX, hand[8].y.coerceIn(0f, 1f), point.x / w, point.y / h),
      lastGesture,
      pointerVisible,
      isPaused,
    )
  }

  private fun finishPinch(end: PointF, now: Long) {
    val start = pinchStart ?: return
    val duration = (now - pinchStartedAt).coerceIn(80L, 1400L)
    val moved = hypot(end.x - start.x, end.y - start.y)
    val screenWidth = max(mainWidth, 1f)
    val label: String
    if (moved > screenWidth * 0.055f) {
      val points = (pinchSamples + listOf(end)).distinctBy { "${(it.x / 6).toInt()}-${(it.y / 6).toInt()}" }
      HandPilotAccessibilityService.dispatchPath(points, duration.coerceAtLeast(150L), "Drag")
      label = "Drag"
    } else if (duration >= 720L) {
      HandPilotAccessibilityService.dispatchPath(listOf(start, PointF(start.x + 1f, start.y + 1f)), 880L, "Long press")
      label = "Long press"
    } else {
      HandPilotAccessibilityService.dispatchPath(listOf(end, PointF(end.x + 1f, end.y + 1f)), 70L, "Tap")
      label = "Tap"
    }
    lastGesture = label
    pinchStart = null
    pinchSamples.clear()
    HandPilotEventHub.emit("onCommand", mapOf("command" to label, "accepted" to (HandPilotAccessibilityService.current != null)))
  }

  private fun detectSwipe(palm: Landmark, now: Long) {
    val previous = previousPalm ?: return
    val elapsed = now - previousPalmAt
    if (elapsed in 80L..720L && now - lastSwipeAt > 850L) {
      val dx = previous.x - palm.x // mirrored: matches what the user sees
      val dy = palm.y - previous.y
      val point = toMappedScreen(palm)
      when {
        abs(dx) > 0.21f && abs(dx) > abs(dy) * 1.15f -> {
          if (dx < 0f) {
            HandPilotAccessibilityService.perform("back")
            lastGesture = "Back"
          } else {
            val y = point.y.coerceIn(40f, max(mainHeight - 40f, 40f))
            HandPilotAccessibilityService.dispatchPath(listOf(PointF(mainWidth * 0.28f, y), PointF(mainWidth * 0.74f, y)), 260L, "Swipe right")
            lastGesture = "Swipe right"
          }
          lastSwipeAt = now
          previousPalm = PointF(palm.x, palm.y)
          previousPalmAt = now
        }
        abs(dy) > 0.23f && abs(dy) > abs(dx) * 1.15f -> {
          val x = point.x.coerceIn(32f, max(mainWidth - 32f, 32f))
          val y = point.y.coerceIn(mainHeight * 0.25f, mainHeight * 0.78f)
          val from = if (dy < 0f) PointF(x, y + mainHeight * 0.20f) else PointF(x, y - mainHeight * 0.20f)
          val to = if (dy < 0f) PointF(x, y - mainHeight * 0.20f) else PointF(x, y + mainHeight * 0.20f)
          HandPilotAccessibilityService.dispatchPath(listOf(from, to), 300L, if (dy < 0f) "Scroll up" else "Scroll down")
          lastGesture = if (dy < 0f) "Scroll up" else "Scroll down"
          lastSwipeAt = now
          previousPalm = PointF(palm.x, palm.y)
          previousPalmAt = now
        }
      }
    }
    if (now - previousPalmAt > 750L) {
      previousPalm = PointF(palm.x, palm.y)
      previousPalmAt = now
    }
  }

  private fun detectTwoHandZoom(first: List<Landmark>, second: List<Landmark>, now: Long) {
    val a = first[8]
    val b = second[8]
    val distance = distance(a, b)
    val previous = previousPairDistance
    val previousPoints = previousPairPoints
    if (previous != null && previousPoints != null && now - previousPairAt in 60L..800L && abs(distance - previous) > 0.14f) {
      val startA = toMappedScreen(previousPoints.first)
      val startB = toMappedScreen(previousPoints.second)
      val endA = toMappedScreen(a)
      val endB = toMappedScreen(b)
      HandPilotAccessibilityService.dispatchMultiTouch(startA, startB, endA, endB, 280L, "Two-hand zoom")
      lastGesture = if (distance > previous) "Zoom out" else "Zoom in"
      previousPairDistance = null
    } else {
      previousPairDistance = distance
      previousPairAt = now
      previousPairPoints = a to b
    }
  }

  private fun toRawScreen(point: Landmark): PointF {
    val metrics = screenMetrics()
    return PointF((1f - point.x.coerceIn(0f, 1f)) * metrics.widthPixels, point.y.coerceIn(0f, 1f) * metrics.heightPixels)
  }

  private fun toMappedScreen(point: Landmark): PointF {
    val raw = toRawScreen(point)
    val anchor = calibrationAnchor
    val x = if (anchor == null) raw.x else mainWidth / 2f + (raw.x - anchor.x) * sensitivity
    val y = if (anchor == null) raw.y else mainHeight / 2f + (raw.y - anchor.y) * sensitivity
    return PointF(x.coerceIn(0f, mainWidth), y.coerceIn(0f, mainHeight))
  }

  @Suppress("DEPRECATION")
  private fun screenMetrics(): DisplayMetrics {
    val metrics = DisplayMetrics()
    val manager = HandPilotAccessibilityService.current?.getSystemService(WindowManager::class.java)
    if (manager != null) manager.defaultDisplay.getRealMetrics(metrics)
    else {
      val system = android.content.res.Resources.getSystem().displayMetrics
      metrics.setTo(system)
    }
    return metrics
  }

  private fun distance(a: Landmark, b: Landmark): Float = hypot(a.x - b.x, a.y - b.y)
}
