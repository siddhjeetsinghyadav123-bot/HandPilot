package expo.modules.handpilot

import android.content.Context
import android.view.View.MeasureSpec
import androidx.camera.view.PreviewView
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView

class HandPilotView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {
  private val cameraPreview = PreviewView(context).apply {
    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
    scaleType = PreviewView.ScaleType.FIT_CENTER
    contentDescription = "Live front camera hand-tracking preview"
  }

  init {
    addView(cameraPreview, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    HandPilotPreviewRegistry.attach(cameraPreview)
  }

  // React Native does not lay out natively-added children, so size the preview ourselves.
  override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
    val w = r - l
    val h = b - t
    cameraPreview.measure(
      MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
      MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY),
    )
    cameraPreview.layout(0, 0, w, h)
  }

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    HandPilotPreviewRegistry.attach(cameraPreview)
  }

  override fun onDetachedFromWindow() {
    HandPilotPreviewRegistry.detach(cameraPreview)
    super.onDetachedFromWindow()
  }
}
