package expo.modules.handpilot

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

internal object HandPilotPreviewRegistry {
  @Volatile private var previewUseCase: Preview? = null
  @Volatile private var attachedView: PreviewView? = null

  fun attach(view: PreviewView) {
    attachedView = view
    previewUseCase?.setSurfaceProvider(view.surfaceProvider)
  }

  fun detach(view: PreviewView) {
    if (attachedView === view) {
      attachedView = null
      previewUseCase?.setSurfaceProvider(null)
    }
  }

  fun setPreview(useCase: Preview?) {
    previewUseCase = useCase
    attachedView?.let { useCase?.setSurfaceProvider(it.surfaceProvider) }
  }
}

class HandPilotTrackingService : LifecycleService() {
  private var cameraProvider: ProcessCameraProvider? = null
  private var landmarker: HandLandmarker? = null
  private var analysisExecutor: ExecutorService? = null
  private var lastUiEventAt = 0L
  private var cameraBound = false
  private var starting = false
  private var lastFrameTimestamp = 0L

  companion object {
    const val ACTION_STOP = "expo.modules.handpilot.STOP_TRACKING"
    private const val NOTIFICATION_CHANNEL = "handpilot_tracking"
    private const val NOTIFICATION_ID = 6214
    @Volatile var isRunning: Boolean = false
      private set

    fun hasCameraPermission(context: Context): Boolean =
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    fun hasNotificationPermission(context: Context): Boolean =
      Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    super.onStartCommand(intent, flags, startId)
    if (intent?.action == ACTION_STOP) {
      stopSelf()
      return START_NOT_STICKY
    }
    if (!hasCameraPermission(this)) {
      HandPilotEventHub.emit("onTrackingState", mapOf("state" to "error", "message" to "Camera permission is required."))
      stopSelf()
      return START_NOT_STICKY
    }
    createNotificationChannel()
    try {
      val notification = buildNotification()
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
    } catch (error: Exception) {
      HandPilotEventHub.emit("onTrackingState", mapOf("state" to "error", "message" to (error.message ?: "Unable to start camera tracking.")))
      stopSelf()
      return START_NOT_STICKY
    }

    if (!cameraBound && !starting) {
      starting = true
      isRunning = true
      HandPilotEventHub.emit("onTrackingState", mapOf("state" to "starting", "message" to "Starting on-device hand tracking."))
      if (initializeLandmarker()) bindCamera() else starting = false
    }
    return START_NOT_STICKY
  }

  override fun onBind(intent: Intent): IBinder? = super.onBind(intent)

  private fun initializeLandmarker(): Boolean {
    try {
      val options = HandLandmarker.HandLandmarkerOptions.builder()
        .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
        .setRunningMode(RunningMode.LIVE_STREAM)
        .setNumHands(2)
        .setMinHandDetectionConfidence(0.55f)
        .setMinHandPresenceConfidence(0.55f)
        .setMinTrackingConfidence(0.55f)
        .setResultListener { result: HandLandmarkerResult, _ -> handleResult(result) }
        .setErrorListener { error ->
          HandPilotEventHub.emit("onTrackingState", mapOf("state" to "error", "message" to (error.message ?: "Hand tracking stopped unexpectedly.")))
        }
        .build()
      landmarker = HandLandmarker.createFromOptions(applicationContext, options)
      return true
    } catch (error: Exception) {
      HandPilotEventHub.emit("onTrackingState", mapOf("state" to "error", "message" to (error.message ?: "Could not load the hand model.")))
      stopSelf()
      return false
    }
  }

  private fun bindCamera() {
    val future = ProcessCameraProvider.getInstance(this)
    future.addListener({
      try {
        val provider = future.get()
        cameraProvider = provider
        val preview = Preview.Builder().build()
        HandPilotPreviewRegistry.setPreview(preview)
        val analysis = ImageAnalysis.Builder()
          .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
          .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
          .build()
        analysisExecutor = Executors.newSingleThreadExecutor()
        analysis.setAnalyzer(analysisExecutor!!) { image -> analyzeFrame(image) }
        provider.unbindAll()
        provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
        cameraBound = true
        starting = false
        HandPilotEventHub.emit("onTrackingState", mapOf("state" to "tracking", "message" to "Camera active. Hand processing stays on this device."))
      } catch (error: Exception) {
        starting = false
        HandPilotEventHub.emit("onTrackingState", mapOf("state" to "error", "message" to (error.message ?: "Unable to open the front camera.")))
        stopSelf()
      }
    }, ContextCompat.getMainExecutor(this))
  }

  private fun analyzeFrame(image: ImageProxy) {
    try {
      val detector = landmarker ?: return
      val bitmap = image.toBitmap()
      val rotation = image.imageInfo.rotationDegrees
      val upright = if (rotation == 0) bitmap else Bitmap.createBitmap(
        bitmap, 0, 0, bitmap.width, bitmap.height,
        Matrix().apply { postRotate(rotation.toFloat()) },
        true,
      )
      // MediaPipe requires strictly increasing timestamps.
      val timestamp = maxOf(SystemClock.uptimeMillis(), lastFrameTimestamp + 1)
      lastFrameTimestamp = timestamp
      detector.detectAsync(BitmapImageBuilder(upright).build(), timestamp)
    } catch (error: Exception) {
      HandPilotEventHub.emit("onTrackingState", mapOf("state" to "error", "message" to (error.message ?: "Could not process the camera frame.")))
    } finally {
      image.close()
    }
  }

  private fun handleResult(result: HandLandmarkerResult) {
    val hands = result.landmarks().map { hand ->
      hand.map { point -> Landmark(point.x(), point.y(), point.z()) }
    }
    val snapshot = HandPilotGestureController.process(hands)
    val now = SystemClock.elapsedRealtime()
    if (now - lastUiEventAt < 45L) return
    lastUiEventAt = now
    val pointer = snapshot.pointer?.let {
      mapOf("x" to it.x, "y" to it.y, "screenX" to it.screenX, "screenY" to it.screenY)
    }
    val serializedHands = hands.map { hand -> hand.map { mapOf("x" to it.x, "y" to it.y, "z" to it.z) } }
    HandPilotEventHub.emit(
      "onHandUpdate",
      mapOf(
        "hands" to serializedHands,
        "pointer" to pointer,
        "gesture" to snapshot.gesture,
        "pointerVisible" to snapshot.pointerVisible,
        "paused" to snapshot.paused,
        "tracking" to isRunning,
      ),
    )
  }

  private fun buildNotification(): Notification {
    val stopIntent = Intent(this, HandPilotTrackingService::class.java).setAction(ACTION_STOP)
    val stopPending = PendingIntent.getService(
      this,
      0,
      stopIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )
    val launch = packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
    val launchPending = launch?.let {
      PendingIntent.getActivity(this, 1, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL)
      .setSmallIcon(android.R.drawable.ic_menu_view)
      .setContentTitle("HandPilot is tracking")
      .setContentText("Camera hand tracking is on-device. Tap Stop to end it.")
      .setCategory(Notification.CATEGORY_SERVICE)
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .setContentIntent(launchPending)
      .addAction(android.R.drawable.ic_media_pause, "Stop tracking", stopPending)
      .build()
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager = getSystemService(NotificationManager::class.java)
      val channel = NotificationChannel(NOTIFICATION_CHANNEL, "Hand tracking", NotificationManager.IMPORTANCE_LOW).apply {
        description = "Visible while camera hand tracking is active."
      }
      manager.createNotificationChannel(channel)
    }
  }

  override fun onDestroy() {
    isRunning = false
    cameraBound = false
    starting = false
    runCatching { cameraProvider?.unbindAll() }
    cameraProvider = null
    HandPilotPreviewRegistry.setPreview(null)
    analysisExecutor?.shutdownNow()
    analysisExecutor = null
    runCatching { landmarker?.close() }
    landmarker = null
    HandPilotGestureController.reset()
    HandPilotEventHub.emit("onTrackingState", mapOf("state" to "stopped", "message" to "Hand tracking stopped."))
    super.onDestroy()
  }
}
