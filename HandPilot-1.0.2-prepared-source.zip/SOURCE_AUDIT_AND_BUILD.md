# HandPilot 1.0.2 — source audit and build handoff

## Changes made in this prepared source
- Synchronized Expo app version and Android Gradle version to `1.0.2`.
- Set Android `versionCode` to `3`, so this build can be installed as an update over versionCode 2 (provided the signing key matches).

## Static checks completed on the supplied ZIP
- ZIP archive integrity check passed.
- All JSON files parsed successfully.
- All XML files parsed successfully.
- Native Android source contains CameraX preview/analysis, MediaPipe Hand Landmarker, a foreground camera service, gesture controller, and AccessibilityService.
- Bundled `hand_landmarker.task` model is present.
- Both ARM64 and ARMv7 support were present in the earlier supplied APK; this source config explicitly requests both ABIs.

## Not verified
- Kotlin/Gradle compilation: not run; this environment has no Android SDK, Gradle installation/cache, or project `node_modules`.
- TypeScript compilation and automated tests: not run in this environment.
- Runtime camera preview, hand landmarks, gesture accuracy, Accessibility actions, thermal behavior, battery use, and Android-version compatibility: require a built APK and physical-device tests.
- APK signature: cannot be verified until a new APK is produced and checked with Android `apksigner`.

## Build
Use the project's configured `apk` EAS profile / managed Android build dashboard to produce an APK. Keep the signing credentials in the build provider's secure credential flow. Do not install over an existing app unless the new APK is signed with the same key; otherwise uninstall the old app first (this removes its local app data).

## Device acceptance test
1. Install the APK and launch it.
2. Grant camera and notification permissions when requested.
3. Start HandPilot and confirm the live front-camera preview is visible inside the app.
4. Hold one hand in frame and confirm 21 landmarks appear and the hand count changes from 0 to 1.
5. Enable HandPilot in Android Accessibility settings.
6. Test pointer visibility, pinch tap, pinch drag, left/right/up/down swipes, fist pause, and open-palm resume.
7. Test Back/Home/Recents and stop tracking from both the app and ongoing notification.
8. Repeat after locking/unlocking and after returning from another app; check for camera errors and excessive heat.
