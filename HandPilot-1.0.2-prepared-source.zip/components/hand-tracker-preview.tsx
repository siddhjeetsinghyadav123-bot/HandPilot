import { useMemo, useState } from 'react';
import { View, StyleSheet, type LayoutChangeEvent, type StyleProp, type ViewStyle } from 'react-native';
import Svg, { Circle, Line } from 'react-native-svg';
import HandPilotView from '@/modules/handpilot/src/HandPilotView';
import type { HandUpdate, Landmark } from '@/modules/handpilot/src/HandPilot.types';

const CONNECTIONS: ReadonlyArray<readonly [number, number]> = [
  [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [0, 17], [17, 18], [18, 19], [19, 20],
];

type Props = {
  update: HandUpdate | null;
  cameraReady: boolean;
  style?: StyleProp<ViewStyle>;
};

export function HandTrackerPreview({ update, cameraReady, style }: Props) {
  const [size, setSize] = useState({ width: 1, height: 1 });
  const onLayout = (event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;
    setSize({ width, height });
  };
  const hands = update?.hands ?? [];
  const pointer = update?.pointer;
  const visible = cameraReady && hands.length > 0;

  const renderedHands = useMemo(() => hands.map((hand, handIndex) => ({ hand, handIndex })), [hands]);

  return (
    <View onLayout={onLayout} style={[styles.frame, style]}>
      {cameraReady ? <HandPilotView style={StyleSheet.absoluteFill} /> : <View style={styles.darkStage} />}
      {visible && (
        <Svg width={size.width} height={size.height} style={[StyleSheet.absoluteFill, { pointerEvents: 'none' }]}>
          {renderedHands.flatMap(({ hand, handIndex }) => {
            const safeHand = hand.slice(0, 21) as Landmark[];
            const lines = CONNECTIONS.flatMap(([a, b], lineIndex) => {
              const start = safeHand[a];
              const end = safeHand[b];
              if (!start || !end) return [];
              return [
                <Line
                  key={`line-${handIndex}-${lineIndex}`}
                  x1={(1 - start.x) * size.width}
                  y1={start.y * size.height}
                  x2={(1 - end.x) * size.width}
                  y2={end.y * size.height}
                  stroke={handIndex === 0 ? '#83F7CA' : '#A996FF'}
                  strokeWidth={2}
                  strokeLinecap="round"
                  opacity={0.86}
                />,
              ];
            });
            const dots = safeHand.map((point, index) => (
              <Circle
                key={`dot-${handIndex}-${index}`}
                cx={(1 - point.x) * size.width}
                cy={point.y * size.height}
                r={index === 0 || index === 8 ? 4.5 : 3}
                fill={index === 8 ? '#F3FFFB' : handIndex === 0 ? '#83F7CA' : '#A996FF'}
                stroke="#07111B"
                strokeWidth={1.5}
              />
            ));
            return [...lines, ...dots];
          })}
          {pointer?.x !== undefined && update?.pointerVisible && (
            <Circle
              cx={pointer.x * size.width}
              cy={pointer.y * size.height}
              r={13}
              fill="rgba(131,247,202,0.12)"
              stroke="#E8FFF6"
              strokeWidth={2}
            />
          )}
        </Svg>
      )}
      {!cameraReady && (
        <View style={[styles.permissionLabel, { pointerEvents: 'none' }]}>
          <View style={styles.reticle}>
            <View style={styles.reticleH} />
            <View style={styles.reticleV} />
          </View>
        </View>
      )}
      {cameraReady && !visible && (
        <View style={[styles.noHandPill, { pointerEvents: 'none' }]}>
          <View style={styles.searchDot} />
        </View>
      )}
      {visible && (
        <View style={[styles.cornerMark, { pointerEvents: 'none' }]}>
          <View style={styles.cornerLineH} />
          <View style={styles.cornerLineV} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  frame: { width: '100%', height: 284, borderRadius: 26, overflow: 'hidden', backgroundColor: '#0C1422', borderWidth: 1, borderColor: '#263449' },
  darkStage: { ...StyleSheet.absoluteFill, backgroundColor: '#0C1422' },
  permissionLabel: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center' },
  reticle: { width: 62, height: 62, borderRadius: 31, borderWidth: 1, borderColor: 'rgba(131,247,202,0.56)', alignItems: 'center', justifyContent: 'center' },
  reticleH: { position: 'absolute', width: 86, height: 1, backgroundColor: 'rgba(131,247,202,0.2)' },
  reticleV: { position: 'absolute', height: 86, width: 1, backgroundColor: 'rgba(131,247,202,0.2)' },
  noHandPill: { position: 'absolute', top: 14, right: 14, width: 10, height: 10, borderRadius: 5, backgroundColor: '#F3B96B', borderWidth: 2, borderColor: 'rgba(7,17,27,0.9)' },
  searchDot: { flex: 1, borderRadius: 5, backgroundColor: '#F3B96B' },
  cornerMark: { position: 'absolute', top: 16, left: 16, width: 24, height: 24, borderTopWidth: 2, borderLeftWidth: 2, borderColor: 'rgba(131,247,202,0.75)' },
  cornerLineH: { position: 'absolute', width: 1, height: 24, backgroundColor: 'rgba(131,247,202,0.75)', right: -20, top: -2 },
  cornerLineV: { position: 'absolute', width: 24, height: 1, backgroundColor: 'rgba(131,247,202,0.75)', bottom: -20, left: -2 },
});
