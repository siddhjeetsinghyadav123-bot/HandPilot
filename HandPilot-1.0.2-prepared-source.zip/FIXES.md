# HandPilot — fixes in this revision

Found by static review (no Android SDK / network was available, so nothing was compiled here).

## Kotlin compile errors (very likely the cause of the failed Dashboard builds)
1. `HandPilotTrackingService`: `MediaImageBuilder(...).setRotation(...)` is not a MediaPipe API. Frames are now
   converted with `ImageProxy.toBitmap()` (RGBA_8888), rotated, and passed via `BitmapImageBuilder`.
2. `HandPilotGestureController`: public functions exposed `internal` types (`Landmark`, `ControllerSnapshot`) -> now public.
3. `HandPilotGestureController`: two-hand zoom passed `PointF` where `Landmark` was required -> stored as `Landmark`.
4. `HandPilotGestureController`: `svc?.dispatchPath(...)` called a companion function on an instance -> now `HandPilotAccessibilityService.dispatchPath(...)`.

## Runtime / gesture bugs
5. Left/right swipes were inverted (raw camera x is un-mirrored). Sweep left = Back now matches what the user sees.
6. Pointing with the index finger counted as a fist and kept pausing control. Fist now means all four fingers folded, held 350 ms.
7. Service returned `START_STICKY` (Android 12+ can crash restarting a camera foreground service from the background) -> `START_NOT_STICKY`.
8. Double start could create two landmarkers; added a `starting` guard, and a failed model load no longer still binds the camera.
9. MediaPipe timestamps are forced strictly increasing.
10. `HandPilotView` now measures/lays out its `PreviewView` itself (React Native does not lay out native children).

## Config
11. `plugins/with-handpilot.js` imported `@expo/config-plugins`, which is not a dependency (breaks under pnpm); now `expo/config-plugins`.

## Still unverified
No APK has been built or tested on a phone. Build via the Dashboard (`apk` profile) or `eas build -p android --profile apk`.
