# HandPilot — implementation and design plan

## Product approach

HandPilot is an Android-first, hands-free controller. A local Expo module will own the camera and native Android integration: CameraX supplies frames to MediaPipe Hand Landmarker, which emits normalized hand landmarks to React Native for the in-app tracking view. Android AccessibilityService will perform supported global actions and injected touch gestures. A camera foreground service will keep tracking alive after the user leaves HandPilot, with an ongoing notification and an explicit stop action. Camera frames and landmark data remain on-device; they are not uploaded or recorded.

The home screen will show the live front-camera feed with an overlaid 21-point skeleton, the tracked-hand count, a visible pointer, and a simple tracking-state signal. Controls will include guided camera and Accessibility permission setup, calibration, pointer sensitivity/smoothing, a large pause/stop action, direct system-action buttons, and a command reference. The UI will distinguish preview, permission-required, ready, tracking, paused, and unsupported states. It will never imply that controls are active until Android grants the required permissions.

Hand gestures will map to the agreed behavior: an open palm reveals the pointer/control HUD; a brief thumb-index pinch taps; a longer pinch sends a long-press; a pinch held while the hand moves becomes a drag; a fast vertical hand sweep requests a scroll; a fast horizontal sweep provides navigation/swipe behavior; a closed fist pauses or cancels; and two separated hands moving closer/farther request a pinch-zoom gesture where supported. Android global actions will be exposed as safe, clearly labeled one-tap controls and may also be mapped to configurable gestures. Android version, target app, camera performance, and protected screens may limit some actions. User credentials and protected screens remain out of scope.

The managed starter is fixed Expo/React Native. Native code will be implemented as a local Expo module with Android services and config-plugin manifest/resource additions, not as an Expo-Go-only prototype. The starter backend/database remain unused by the controller. TypeScript and native source checks will be run where available; native release builds must be produced through the managed Dashboard after an accepted checkpoint. Configure `apk` for an installable internal APK and `production` for a Google Play AAB. Building either artifact does not publish it; only report an artifact after the Dashboard returns it, and do not submit a public store release without the user's explicit approval.

## Project structure

- `app/(tabs)/index.tsx`: controller dashboard, preview overlay, controls, permission setup, and command access.
- `components/`: reusable tracker preview, status indicators, action buttons, and permission/command panels.
- `lib/handpilot/`: TypeScript native bridge, types, gesture-command metadata, and platform capability helpers.
- `modules/handpilot/android/`: local Expo native module, CameraX/MediaPipe integration, foreground camera service, AccessibilityService, pointer overlay, and Android resources.
- `plugins/with-handpilot.ts`: Android manifest and accessibility XML/resource configuration preserved by Expo prebuild.
- `assets/images/`: distinct square launcher icon and matching Android adaptive icons/splash/favicon.
- `plan.md` and `TODO.md`: approved design/implementation direction and independently deliverable outcomes.

## Design direction

Three initial directions (sampling probabilities):
- **Optical lab instrument** — 0.07: graphite panels, measured signal color, compact tracking readouts.
- **Soft accessibility companion** — 0.03: warm neutrals, large touch targets, approachable coaching.
- **Neon motion console** — 0.08: electric accent strokes, a camera-stage centerpiece, precise status cues.

Choose **Optical lab instrument**: a calm technical interface that feels precise, not playful or alarming.

- **Design Movement:** Contemporary instrument-panel design with restrained Swiss typography and optical measurement cues.
- **Core Principles:** Make live state immediately legible; separate safe setup from active control; give pause/stop the strongest affordance; keep controls reachable one-handed.
- **Color Philosophy:** Deep ink and graphite reduce camera-preview glare; luminous mint signals tracking/ready; amber marks calibration or permission attention; muted violet distinguishes hand data from system actions.
- **Layout Paradigm:** A vertically staged instrument console: compact brand/status rail, wide camera viewport, single primary control, then short action shelves and a scrollable command guide. Avoid dense dashboards.
- **Signature Elements:** Fine orbital landmark traces; a mint reticle and confidence pulse; small uppercase instrument labels with generous value typography.
- **Interaction Philosophy:** Every control reports what will happen before it runs. Tracking is opt-in, pause is always close by, and system actions require an explicit gesture or button rather than an accidental hand pose.
- **Animation:** Use restrained 180–260 ms transitions; ease the reticle with low-pass smoothing; pulse a single mint ring only while a hand is confidently detected; stop all nonessential motion when paused or reduced motion is enabled.
- **Typography System:** Use the platform system sans for readable body text, with a compact medium-weight label face and tabular numerals for confidence/status values; maintain high contrast and 16 pt minimum body copy.
- **Brand Essence:** A precise, private hand-operated control surface for Android; **calm, capable, transparent**.
- **Brand Voice:** Direct and reassuring. Example lines: “Your hand is visible. Tracking stays on this device.” “Pause any time; phone controls stop immediately.”
- **Wordmark & Logo:** HandPilot wordmark paired with a custom mint fingertip/reticle mark, rendered as a clean high-contrast vector-style square launcher icon without pre-rounded corners.
- **Signature Brand Color:** Signal Mint, a bright mint chosen to remain distinct from neutral system alerts and violet landmark traces.
